chrome.runtime.sendMessage({}, function (response) {
    alert(response);
})